<?php

class Fake_Click_Blocker {

    private static $instance = null;

    private function __construct() {
        // Add necessary hooks.
        add_action('wp_head', array($this, 'detect_fake_clicks'));
        add_action('wp_loaded', array($this, 'log_user_visit'));
    }

    public static function get_instance() {
        if (self::$instance == null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function detect_fake_clicks() {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $ip_address = $_SERVER['REMOTE_ADDR'];

        if ($this->is_fake_click($user_agent, $ip_address)) {
            wp_die('Erişim Engellendi.');
        }
    }

    private function is_fake_click($user_agent, $ip_address) {
        $options = get_option('fcb_settings');
        $blocked_user_agents = isset($options['block_user_agents']) ? explode("\n", $options['block_user_agents']) : array();
        $blocked_ip_addresses = isset($options['block_ip_addresses']) ? explode("\n", $options['block_ip_addresses']) : array();
        $blocked_countries = isset($options['blocked_countries']) ? explode("\n", $options['blocked_countries']) : array();
        $blocked_asn = isset($options['blocked_asn']) ? explode("\n", $options['blocked_asn']) : array();

        $country = $this->get_country($ip_address);
        $asn = $this->get_asn($ip_address);

        foreach ($blocked_user_agents as $blocked_user_agent) {
            if (stripos($user_agent, trim($blocked_user_agent)) !== false) {
                $this->log_banned_user($user_agent, $ip_address);
                return true;
            }
        }

        foreach ($blocked_ip_addresses as $blocked_ip_address) {
            if (trim($blocked_ip_address) === $ip_address) {
                $this->log_banned_user($user_agent, $ip_address);
                return true;
            }
        }

        foreach ($blocked_countries as $blocked_country) {
            if (trim($blocked_country) === $country) {
                $this->log_banned_user($user_agent, $ip_address);
                return true;
            }
        }

        foreach ($blocked_asn as $blocked_asn_entry) {
            if (trim($blocked_asn_entry) === $asn) {
                $this->log_banned_user($user_agent, $ip_address);
                return true;
            }
        }

        return false;
    }

    private function get_country($ip_address) {
        // Get the country code from IP address using a service like ipinfo.io
        $response = wp_remote_get("https://ipinfo.io/{$ip_address}/country");
        if (is_wp_error($response)) {
            return '';
        }
        return trim(wp_remote_retrieve_body($response));
    }

    private function get_asn($ip_address) {
        // Get the ASN from IP address using a service like ipinfo.io
        $response = wp_remote_get("https://ipinfo.io/{$ip_address}/org");
        if (is_wp_error($response)) {
            return '';
        }
        return trim(wp_remote_retrieve_body($response));
    }

    public function log_user_visit() {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $current_time = current_time('mysql');
        $page_visited = esc_url($_SERVER['REQUEST_URI']);

        global $wpdb;

        // Differentiate between admin and user logs
        if (is_admin()) {
            $table_name = $wpdb->prefix . 'fcb_admin_logs';
        } else {
            $table_name = $wpdb->prefix . 'fcb_user_logs';
        }

        $wpdb->insert($table_name, array(
            'ip_address' => $ip_address,
            'user_agent' => $user_agent,
            'visit_time' => $current_time,
            'page_visited' => $page_visited,
            'banned' => 0
        ));
    }

    public function log_banned_user($user_agent, $ip_address) {
        $current_time = current_time('mysql');
        $page_visited = esc_url($_SERVER['REQUEST_URI']);

        global $wpdb;
        $table_name = $wpdb->prefix . 'fcb_user_logs';

        $wpdb->insert($table_name, array(
            'ip_address' => $ip_address,
            'user_agent' => $user_agent,
            'visit_time' => $current_time,
            'page_visited' => $page_visited,
            'banned' => 1
        ));
    }
}
?>

<?php

require_once(plugin_dir_path(__FILE__) . 'vendor/autoload.php');

function generate_pdf_report($logs) {
    $mpdf = new \Mpdf\Mpdf();

    $html = '<h1>Gelişmiş Rapor</h1>';
    $html .= '<table border="1" cellpadding="10">';
    $html .= '<tr><th>IP Adresi</th><th>Kullanıcı Aracısı</th><th>Ziyaret Zamanı</th><th>Ziyaret Edilen Sayfa</th><th>Engellendi</th></tr>';

    foreach ($logs as $log) {
        $html .= '<tr>';
        $html .= '<td>' . esc_html($log->ip_address) . '</td>';
        $html .= '<td>' . esc_html($log->user_agent) . '</td>';
        $html .= '<td>' . esc_html($log->visit_time) . '</td>';
        $html .= '<td>' . esc_html($log->page_visited) . '</td>';
        $html .= '<td>' . ($log->banned ? 'Evet' : 'Hayır') . '</td>';
        $html .= '</tr>';
    }

    $html .= '</table>';

    $mpdf->WriteHTML($html);
    $mpdf->Output('Gelişmiş_Rapor.pdf', 'D');
}

?>

<?php

class Fake_Click_Blocker_Admin {

    private static $instance = null;

    private function __construct() {
        // Add necessary admin hooks.
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_notices', array($this, 'admin_notices'));
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'add_action_links'));
        add_action('admin_init', array($this, 'settings_init'));
        add_action('admin_post_ban_user', array($this, 'ban_user'));
        add_action('admin_post_unban_user', array($this, 'unban_user'));
        add_action('admin_post_whitelist_user', array($this, 'whitelist_user'));
        add_action('admin_post_delete_log', array($this, 'delete_log'));
        add_action('admin_post_delete_all_logs', array($this, 'delete_all_logs'));
        add_action('admin_post_generate_report', array($this, 'generate_report'));
    }

    public static function get_instance() {
        if (self::$instance == null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function add_admin_menu() {
        add_menu_page(
            'Fake Click Blocker',
            'Fake Click Blocker',
            'manage_options',
            'fake-click-blocker',
            array($this, 'admin_page_content'),
            'dashicons-shield',
            100
        );

        add_submenu_page(
            'fake-click-blocker',
            'Ayarlar',
            'Ayarlar',
            'manage_options',
            'fake-click-blocker-settings',
            array($this, 'admin_page_content')
        );

        add_submenu_page(
            'fake-click-blocker',
            'Kullanıcı Logları',
            'Kullanıcı Logları',
            'manage_options',
            'fake-click-blocker-logs',
            array($this, 'user_logs_page_content')
        );

        add_submenu_page(
            'fake-click-blocker',
            'Admin Logları',
            'Admin Logları',
            'manage_options',
            'fake-click-blocker-admin-logs',
            array($this, 'admin_logs_page_content')
        );

        add_submenu_page(
            'fake-click-blocker',
            'Gelişmiş Raporlama',
            'Gelişmiş Raporlama',
            'manage_options',
            'fake-click-blocker-reports',
            array($this, 'reports_page_content')
        );
    }

    public function admin_notices() {
        $screen = get_current_screen();
        if ($screen->id === 'toplevel_page_fake-click-blocker') {
            ?>
            <div class="notice notice-info is-dismissible">
                <p>
                    <a href="admin.php?page=fake-click-blocker-settings">Ayarlar</a> |
                    <a href="#">SSS</a> |
                    <a href="#">Belgeler</a> |
                    <a href="#">Destek</a>
                </p>
            </div>
            <?php
        }
    }

    public function add_action_links($links) {
        $settings_link = '<a href="admin.php?page=fake-click-blocker-settings">' . __('Ayarlar', 'fake-click-blocker') . '</a>';
        $faq_link = '<a href="#">' . __('SSS', 'fake-click-blocker') . '</a>';
        $docs_link = '<a href="#">' . __('Belgeler', 'fake-click-blocker') . '</a>';
        $support_link = '<a href="#">' . __('Destek', 'fake-click-blocker') . '</a>';
        array_unshift($links, $settings_link, $faq_link, $docs_link, $support_link);
        return $links;
    }

    public function admin_page_content() {
        ?>
        <div class="wrap">
            <h1>Fake Click Blocker Ayarları</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('fcb_settings_group');
                do_settings_sections('fake-click-blocker');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function user_logs_page_content() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fcb_user_logs';

        // Sayfalama
        $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
        $logs_per_page = 10;
        $offset = ($paged - 1) * $logs_per_page;

        // IP Arama
        $ip_search = isset($_GET['ip_search']) ? sanitize_text_field($_GET['ip_search']) : '';

        $where_clause = '';
        if ($ip_search) {
            $where_clause = $wpdb->prepare("WHERE ip_address LIKE %s", '%' . $wpdb->esc_like($ip_search) . '%');
        }

        $total_logs = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where_clause");
        $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name $where_clause ORDER BY visit_time DESC LIMIT %d OFFSET %d", $logs_per_page, $offset));

        $total_pages = ceil($total_logs / $logs_per_page);

        ?>
        <div class="wrap">
            <h1>Kullanıcı Logları</h1>

            <form method="get">
                <input type="hidden" name="page" value="fake-click-blocker-logs">
                <input type="text" name="ip_search" placeholder="IP Adresi Ara" value="<?php echo esc_attr($ip_search); ?>">
                <button type="submit" class="button">Ara</button>
            </form>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('IP Adresi', 'fake-click-blocker'); ?></th>
                        <th><?php _e('Kullanıcı Aracısı', 'fake-click-blocker'); ?></th>
                        <th><?php _e('Ziyaret Zamanı', 'fake-click-blocker'); ?></th>
                        <th><?php _e('Ziyaret Edilen Sayfa', 'fake-click-blocker'); ?></th>
                        <th><?php _e('Engellendi', 'fake-click-blocker'); ?></th>
                        <th><?php _e('İşlemler', 'fake-click-blocker'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log) { ?>
                        <tr <?php if ($log->banned) echo 'style="background-color: #ffb3b3;"'; ?>>
                            <td><a href="https://check-host.net/ip-info?host=<?php echo esc_html($log->ip_address); ?>" target="_blank"><?php echo esc_html($log->ip_address); ?></a></td>
                            <td><?php echo esc_html($log->user_agent); ?></td>
                            <td><?php echo esc_html($log->visit_time); ?></td>
                            <td><?php echo esc_html($log->page_visited); ?></td>
                            <td><?php echo $log->banned ? __('Evet', 'fake-click-blocker') : __('Hayır', 'fake-click-blocker'); ?></td>
                            <td>
                                <?php if ($log->banned) { ?>
                                    <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=unban_user&log_id=' . $log->id), 'unban_user_' . $log->id); ?>" class="button"><?php _e('Ban Kaldır', 'fake-click-blocker'); ?></a>
                                <?php } else { ?>
                                    <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=ban_user&log_id=' . $log->id), 'ban_user_' . $log->id); ?>" class="button"><?php _e('Banla', 'fake-click-blocker'); ?></a>
                                    <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=whitelist_user&log_id=' . $log->id), 'whitelist_user_' . $log->id); ?>" class="button"><?php _e('Beyaz Listeye Ekle', 'fake-click-blocker'); ?></a>
                                <?php } ?>
                                <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=delete_log&log_id=' . $log->id), 'delete_log_' . $log->id); ?>" class="button"><?php _e('Sil', 'fake-click-blocker'); ?></a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <?php
            if ($total_pages > 1) {
                echo '<div class="tablenav"><div class="tablenav-pages">';
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => __('&laquo;', 'fake-click-blocker'),
                    'next_text' => __('&raquo;', 'fake-click-blocker'),
                    'total' => $total_pages,
                    'current' => $paged
                ));
                echo '</div></div>';
            }
            ?>

            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <input type="hidden" name="action" value="delete_all_logs">
                <?php wp_nonce_field('delete_all_logs', 'delete_all_logs_nonce'); ?>
                <button type="submit" class="button button-danger"><?php _e('Tüm Logları Temizle', 'fake-click-blocker'); ?></button>
            </form>
        </div>
        <?php
    }

    public function admin_logs_page_content() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fcb_admin_logs';

        // Sayfalama
        $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
        $logs_per_page = 10;
        $offset = ($paged - 1) * $logs_per_page;

        // IP Arama
        $ip_search = isset($_GET['ip_search']) ? sanitize_text_field($_GET['ip_search']) : '';

        $where_clause = '';
        if ($ip_search) {
            $where_clause = $wpdb->prepare("WHERE ip_address LIKE %s", '%' . $wpdb->esc_like($ip_search) . '%');
        }

        $total_logs = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where_clause");
        $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name $where_clause ORDER BY visit_time DESC LIMIT %d OFFSET %d", $logs_per_page, $offset));

        $total_pages = ceil($total_logs / $logs_per_page);

        ?>
        <div class="wrap">
            <h1>Admin Logları</h1>

            <form method="get">
                <input type="hidden" name="page" value="fake-click-blocker-admin-logs">
                <input type="text" name="ip_search" placeholder="IP Adresi Ara" value="<?php echo esc_attr($ip_search); ?>">
                <button type="submit" class="button">Ara</button>
            </form>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('IP Adresi', 'fake-click-blocker'); ?></th>
                        <th><?php _e('Kullanıcı Aracısı', 'fake-click-blocker'); ?></th>
                        <th><?php _e('Ziyaret Zamanı', 'fake-click-blocker'); ?></th>
                        <th><?php _e('Ziyaret Edilen Sayfa', 'fake-click-blocker'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log) { ?>
                        <tr>
                            <td><a href="https://check-host.net/ip-info?host=<?php echo esc_html($log->ip_address); ?>" target="_blank"><?php echo esc_html($log->ip_address); ?></a></td>
                            <td><?php echo esc_html($log->user_agent); ?></td>
                            <td><?php echo esc_html($log->visit_time); ?></td>
                            <td><?php echo esc_html($log->page_visited); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <?php
            if ($total_pages > 1) {
                echo '<div class="tablenav"><div class="tablenav-pages">';
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => __('&laquo;', 'fake-click-blocker'),
                    'next_text' => __('&raquo;', 'fake-click-blocker'),
                    'total' => $total_pages,
                    'current' => $paged
                ));
                echo '</div></div>';
            }
            ?>
        </div>
        <?php
    }

    public function reports_page_content() {
        ?>
        <div class="wrap">
            <h1>Gelişmiş Raporlama</h1>
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <input type="hidden" name="action" value="generate_report">
                <?php wp_nonce_field('generate_report', 'generate_report_nonce'); ?>
                <button type="submit" class="button button-primary"><?php _e('Rapor Oluştur', 'fake-click-blocker'); ?></button>
            </form>
        </div>
        <?php
    }

    public function ban_user() {
        if (!isset($_GET['log_id']) || !wp_verify_nonce($_GET['_wpnonce'], 'ban_user_' . $_GET['log_id'])) {
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'fcb_user_logs';
        $wpdb->update($table_name, array('banned' => 1), array('id' => intval($_GET['log_id'])));

        wp_redirect(admin_url('admin.php?page=fake-click-blocker-logs'));
        exit;
    }

    public function unban_user() {
        if (!isset($_GET['log_id']) || !wp_verify_nonce($_GET['_wpnonce'], 'unban_user_' . $_GET['log_id'])) {
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'fcb_user_logs';
        $wpdb->update($table_name, array('banned' => 0), array('id' => intval($_GET['log_id'])));

        wp_redirect(admin_url('admin.php?page=fake-click-blocker-logs'));
        exit;
    }

    public function whitelist_user() {
        if (!isset($_GET['log_id']) || !wp_verify_nonce($_GET['_wpnonce'], 'whitelist_user_' . $_GET['log_id'])) {
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'fcb_user_logs';
        $log = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($_GET['log_id'])));

        if ($log) {
            $options = get_option('fcb_settings');
            $whitelisted_ips = isset($options['whitelisted_ips']) ? explode("\n", $options['whitelisted_ips']) : array();

            if (!in_array($log->ip_address, $whitelisted_ips)) {
                $whitelisted_ips[] = $log->ip_address;
                $options['whitelisted_ips'] = implode("\n", $whitelisted_ips);
                update_option('fcb_settings', $options);
            }
        }

        wp_redirect(admin_url('admin.php?page=fake-click-blocker-logs'));
        exit;
    }

    public function delete_log() {
        if (!isset($_GET['log_id']) || !wp_verify_nonce($_GET['_wpnonce'], 'delete_log_' . $_GET['log_id'])) {
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'fcb_user_logs';
        $wpdb->delete($table_name, array('id' => intval($_GET['log_id'])));

        wp_redirect(admin_url('admin.php?page=fake-click-blocker-logs'));
        exit;
    }

    public function delete_all_logs() {
        if (!isset($_POST['delete_all_logs_nonce']) || !wp_verify_nonce($_POST['delete_all_logs_nonce'], 'delete_all_logs')) {
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'fcb_user_logs';
        $wpdb->query("TRUNCATE TABLE $table_name");

        wp_redirect(admin_url('admin.php?page=fake-click-blocker-logs'));
        exit;
    }

    public function generate_report() {
        if (!isset($_POST['generate_report_nonce']) || !wp_verify_nonce($_POST['generate_report_nonce'], 'generate_report')) {
            return;
        }

        global $wpdb;
        $user_logs_table = $wpdb->prefix . 'fcb_user_logs';
        $logs = $wpdb->get_results("SELECT * FROM $user_logs_table");

        require_once(plugin_dir_path(__FILE__) . 'pdf_report_generator.php');
        generate_pdf_report($logs);

        wp_redirect(admin_url('admin.php?page=fake-click-blocker-reports'));
        exit;
    }

    public function settings_init() {
        register_setting('fcb_settings_group', 'fcb_settings');

        add_settings_section(
            'fcb_settings_section',
            __('Genel Ayarlar', 'fake-click-blocker'),
            null,
            'fake-click-blocker'
        );

        add_settings_field(
            'fcb_setting_block_user_agents',
            __('Kullanıcı Aracılarını Engelle', 'fake-click-blocker'),
            array($this, 'block_user_agents_render'),
            'fake-click-blocker',
            'fcb_settings_section'
        );

        add_settings_field(
            'fcb_setting_block_ip_addresses',
            __('IP Adreslerini Engelle', 'fake-click-blocker'),
            array($this, 'block_ip_addresses_render'),
            'fake-click-blocker',
            'fcb_settings_section'
        );

        add_settings_field(
            'fcb_setting_whitelisted_ips',
            __('Beyaz Liste IP Adresleri', 'fake-click-blocker'),
            array($this, 'whitelisted_ips_render'),
            'fake-click-blocker',
            'fcb_settings_section'
        );

        add_settings_field(
            'fcb_setting_block_countries',
            __('Ülkeleri Engelle', 'fake-click-blocker'),
            array($this, 'block_countries_render'),
            'fake-click-blocker',
            'fcb_settings_section'
        );

        add_settings_field(
            'fcb_setting_block_asn',
            __('ASN Engelle', 'fake-click-blocker'),
            array($this, 'block_asn_render'),
            'fake-click-blocker',
            'fcb_settings_section'
        );

        add_settings_field(
            'fcb_setting_block_mode',
            __('Engelleme Modu', 'fake-click-blocker'),
            array($this, 'block_mode_render'),
            'fake-click-blocker',
            'fcb_settings_section'
        );
    }

    public function block_user_agents_render() {
        $options = get_option('fcb_settings');
        ?>
        <textarea name="fcb_settings[block_user_agents]" rows="5" cols="50"><?php echo isset($options['block_user_agents']) ? esc_textarea($options['block_user_agents']) : ''; ?></textarea>
        <p class="description"><?php _e('Engellenecek kullanıcı aracısı, her satıra bir tane.', 'fake-click-blocker'); ?></p>
        <?php
    }

    public function block_ip_addresses_render() {
        $options = get_option('fcb_settings');
        ?>
        <textarea name="fcb_settings[block_ip_addresses]" rows="5" cols="50"><?php echo isset($options['block_ip_addresses']) ? esc_textarea($options['block_ip_addresses']) : ''; ?></textarea>
        <p class="description"><?php _e('Engellenecek IP adresleri, her satıra bir tane.', 'fake-click-blocker'); ?></p>
        <?php
    }

    public function whitelisted_ips_render() {
        $options = get_option('fcb_settings');
        ?>
        <textarea name="fcb_settings[whitelisted_ips]" rows="5" cols="50"><?php echo isset($options['whitelisted_ips']) ? esc_textarea($options['whitelisted_ips']) : ''; ?></textarea>
        <p class="description"><?php _e('Beyaz listeye alınacak IP adresleri, her satıra bir tane.', 'fake-click-blocker'); ?></p>
        <?php
    }

    public function block_countries_render() {
        $options = get_option('fcb_settings');
        ?>
        <textarea name="fcb_settings[block_countries]" rows="5" cols="50"><?php echo isset($options['block_countries']) ? esc_textarea($options['block_countries']) : ''; ?></textarea>
        <p class="description"><?php _e('Engellenecek ülke kodları (örnek: US, CN), her satıra bir tane.', 'fake-click-blocker'); ?></p>
        <?php
    }

    public function block_asn_render() {
        $options = get_option('fcb_settings');
        ?>
        <textarea name="fcb_settings[block_asn]" rows="5" cols="50"><?php echo isset($options['block_asn']) ? esc_textarea($options['block_asn']) : ''; ?></textarea>
        <p class="description"><?php _e('Engellenecek ASN, her satıra bir tane.', 'fake-click-blocker'); ?></p>
        <?php
    }

    public function block_mode_render() {
        $options = get_option('fcb_settings');
        $mode = isset($options['block_mode']) ? $options['block_mode'] : 'engelle';
        ?>
        <select name="fcb_settings[block_mode]">
            <option value="engelle" <?php selected($mode, 'engelle'); ?>><?php _e('Engelle', 'fake-click-blocker'); ?></option>
            <option value="uyar" <?php selected($mode, 'uyar'); ?>><?php _e('Uyar', 'fake-click-blocker'); ?></option>
        </select>
        <p class="description"><?php _e('Engelleme modunu seçin.', 'fake-click-blocker'); ?></p>
        <?php
    }
}
?>
